# BAITIA Community Portal V26

GitHub Pages-ready static deployment package for the BAITIA Community Portal.

## Deploy with GitHub Pages

1. Create a new GitHub repository.
2. Upload the contents of this package to the repository root. `index.html` must remain in the root.
3. Make sure the default branch is named `main`.
4. In GitHub, open **Settings > Pages**.
5. Under **Build and deployment > Source**, select **GitHub Actions**.
6. Push/commit the files. The included workflow at `.github/workflows/deploy-pages.yml` will deploy the site.
7. Open the repository's **Actions** tab to confirm the deployment succeeds.
8. The site URL will normally be `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

## Firebase note

If Firebase Authentication rejects the GitHub Pages site after deployment, add the deployed GitHub Pages hostname (for example `YOUR-USERNAME.github.io`) to **Firebase Console > Authentication > Settings > Authorized domains**. Do not expose private server credentials in this repository. The Firebase web configuration already used by the client application is intended for browser use, but Firebase Security Rules must remain properly restricted.

## Included GitHub deployment support

- `.github/workflows/deploy-pages.yml` for GitHub Pages deployment
- `.nojekyll` so GitHub Pages serves the static files directly
- Relative manifest/icon/service-worker paths for repository subfolder hosting
- Service-worker notification routing scoped to the deployed app path
- Existing mobile/PWA and Firebase application files

## Important

Do not rename `index.html`, `manifest.webmanifest`, or `service-worker.js` unless you also update their references in the application.
